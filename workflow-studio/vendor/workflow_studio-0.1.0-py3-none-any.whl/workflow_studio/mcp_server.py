#!/usr/bin/env python3
"""mcp_server.py — a Model Context Protocol (stdio) server for Workflow Studio.

Exposes Workflow Studio's OBSERVE + AUTHOR capabilities to a Claude Code agent as MCP tools, so the
agent and the human collaborate through ONE live surface instead of a script file dropped on disk the
agent is blind to: the agent can discover what the human built, read the DECLARED contract of a design,
inspect OBSERVED run graphs, and draft a workflow back into the human's builder.

Deliberately dependency-free — a hand-rolled JSON-RPC 2.0 loop over stdio (UTF-8, newline-delimited,
one compact message per line) — so the package keeps `dependencies = []` and `uvx workflow-studio mcp`
starts with zero resolution (the strongest mitigation against Claude Code's MCP startup timeout). It
reuses serve.py's service layer, so the honesty invariant holds unchanged: OBSERVED run data carries
taskMatched (False ⇒ heuristic, not measured) + status; a DECLARED design carries `source`
('snapshot' = exactly what ran, 'template' = a mutable fallback that MAY differ) + hasSidecar. The two
are never conflated, and this server can NOT inject a run into a session — the agent runs a fetched
design with its own Workflow tool.

STDIO CONTRACT (get any of these wrong and Claude Code silently disconnects on the first stray byte):
  • stdout carries ONLY compact single-line JSON-RPC — every diagnostic goes to stderr, and we
    reassign sys.stdout→stderr at startup so a stray print() by imported code can't corrupt the stream.
  • flush after every message (Python block-buffers pipes → the classic "connects then hangs").
  • notifications (no id) get NO response; the loop never dies on a bad frame; EOF on stdin = exit.
"""
import argparse
import json
import os
import sys

from . import __version__, serve

# MCP protocol versions we understand; the tools primitives are byte-identical across them, so we echo
# the client's requested version when it is one of these, else advertise our default. NEVER throw on a
# mismatch (that makes the client disconnect) — negotiate.
SUPPORTED_PROTOCOL = {"2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25"}
DEFAULT_PROTOCOL = "2025-06-18"

INSTRUCTIONS = (
    "Workflow Studio: OBSERVE (list_runs/get_run) and AUTHOR (get_workflow/get_run_design/save_workflow) "
    "Claude Code Workflow runs. Honesty rules baked into the data: OBSERVED results (get_run) carry "
    "taskMatched + status — never treat heuristic values (taskMatched=false) or a non-'done' elapsed "
    "span (a lower bound) as a measurement. DECLARED designs (get_workflow/get_run_design) carry source "
    "+ hasSidecar + a decoded `contract` — a 'template'-source design MAY differ from what actually ran, "
    "and hasSidecar=false means the block structure is best-effort recovery, not a faithful design. This "
    "server CANNOT start a run: fetch a design's `script` and execute it with your own Workflow tool."
)

# Scope resolved once at startup. Claude Code injects CLAUDE_PROJECT_DIR into a spawned MCP server's
# env; the uvx-launched process's cwd is NOT reliably the user's workspace, so we resolve the project
# from that env (or an explicit --project), and honestly fall back to "all projects" when unknown —
# never a cwd guess presented as "the current project".
_CTX = {"launch_project": None, "launch_cwd": None, "current_session": None}


def _log(*a):
    print("[workflow-studio mcp]", *a, file=sys.stderr, flush=True)


def _read_scope(args):
    """(project, session) for a scoped read. all_projects=True → project None (whole machine); else the
    launch project (which is itself None — an honest 'all' — when the project could not be determined)."""
    if args.get("all_projects"):
        return None, args.get("session")
    return _CTX["launch_project"], args.get("session")


def _require(args, key):
    val = args.get(key)
    if val in (None, ""):
        raise ValueError(f"'{key}' is required")
    return val


def _run_id(args):
    # required by every tool that takes it — the hand-rolled server doesn't enforce inputSchema.required,
    # so without this a missing run_id would silently act on the newest run (get_run) instead of erroring.
    rid = args.get("run_id") or args.get("runId")
    if not rid:
        raise ValueError("'run_id' is required")
    return rid


# ── tool handlers (thin wrappers over serve.py's transport-agnostic service layer) ──

def _t_list_runs(a):
    project, session = _read_scope(a)
    return {"scope": {"project": project, "session": session, "allProjects": project is None},
            "runs": serve.list_runs(project, session),
            "note": "OBSERVED runs. status live|incomplete|done; a live/incomplete elapsed span is a "
                    "lower bound. Use get_run for the full graph."}


def _t_get_run(a):
    return serve.run_data(_run_id(a))  # routed through run_data → carries real name + taskMatched/status


def _t_list_workflows(a):
    project, session = _read_scope(a)
    return {"scope": {"project": project, "allProjects": project is None},
            "workflows": serve.list_templates(project, session, _CTX["current_session"]),
            "note": "source: builder = a saved block-editor design; cc-saved = grounded in a real run "
                    "record; run = merely OBSERVED (a flow of that name executed) — not a reusable "
                    "declared design. Use get_workflow for a design's script + decoded contract."}


def _t_get_workflow(a):
    detail = serve.template_detail(_require(a, "name"), _CTX["current_session"])
    if not isinstance(detail, dict) or "error" in detail:
        return detail
    detail["contract"] = serve.sidecar_contract(detail.get("script", ""))
    detail["hasSidecar"] = detail["contract"] is not None
    detail["note"] = ("`runs` share this NAME but are NOT proven to have executed this exact script — "
                      "call get_run_design(run_id) (source='snapshot') to confirm what a specific run "
                      "ran. `script` is runnable as-is with your own Workflow tool. hasSidecar=false ⇒ "
                      "no faithful declared contract (best-effort structure only).")
    return detail


def _t_get_run_design(a):
    res = serve.run_design(_run_id(a))
    res["contract"] = serve.sidecar_contract(res.get("script", ""))
    res["hasSidecar"] = res["contract"] is not None
    res["note"] = ("source='snapshot' = the exact script THIS run launched (trust as what-ran); "
                   "'template' = a mutable design that MAY DIFFER from what ran; null = none recorded.")
    return res


def _t_list_projects(a):
    return {"launchProject": _CTX["launch_project"], "projects": serve.list_projects()}


def _t_get_context(a):
    lp = _CTX["launch_project"]
    info = serve._project_info(lp) if lp else None
    return {
        "launchProject": lp,
        "launchProjectPath": (info or {}).get("path"),
        "launchProjectPathExact": (info or {}).get("pathExact"),
        "launchCwd": _CTX["launch_cwd"],
        "currentSession": _CTX["current_session"],
        "projectCount": len(serve.list_projects()),
        "version": __version__,
        "dataDir": serve.DATA_DIR,
        "tasksRoot": serve.TASKS_ROOT,
        "distExists": os.path.isdir(serve.DIST),
        "note": ("launchProject=null ⇒ the project could not be determined (uvx cwd is unreliable); "
                 "set CLAUDE_PROJECT_DIR / pass all_projects, and reads default to ALL projects. "
                 "dataDir is where save_workflow writes — the human's dashboard must run with the SAME "
                 "WORKFLOW_STUDIO_DATA or agent-drafted workflows won't appear in their builder."),
    }


def _t_save_workflow(a):
    res, _code = serve.save_template(_require(a, "name"), _require(a, "script"), a.get("scope", "project"),
                                     _CTX["current_session"], _CTX["launch_project"],
                                     overwrite=bool(a.get("overwrite")))
    if "error" not in res:
        res["note"] = ("Drafted into the human's builder scope (appears in list_workflows). editable="
                       + str(res.get("editable")) + ": false ⇒ opens via LOSSY recovery, not a faithful "
                       "builder design, until re-saved there. This server cannot run it — execute the "
                       "script with your own Workflow tool, or the human picks it up in the builder.")
    return res


def _t_promote_run(a):
    res, _code = serve.make_template(_run_id(a), _require(a, "name"), a.get("scope", "project"),
                                     _CTX["current_session"], _CTX["launch_project"])
    return res


_RUN_ID_PROP = {"run_id": {"type": "string", "description": "runId of the run, e.g. wf_abc123"}}
_SCOPE_PROPS = {
    "all_projects": {"type": "boolean", "description": "Widen from the current project to every project on the machine (default false)"},
    "session": {"type": "string", "description": "Optional: narrow to a single session id"},
}
_WRITE_SCOPE = {"scope": {"type": "string", "enum": ["session", "project", "global"],
                          "description": "Visibility of the saved workflow (default project)"}}


def _obj(props, required=None):
    schema = {"type": "object", "properties": props, "additionalProperties": False}
    if required:
        schema["required"] = required
    return schema


TOOLS = [
    {"name": "get_context", "fn": _t_get_context,
     "description": "The scope this server operates under: launch project (or null if undeterminable), "
                    "project path, current session, plus a doctor view (dataDir/tasksRoot/dist). Call "
                    "FIRST to learn which project your reads/writes target and where drafts land.",
     "inputSchema": _obj({})},
    {"name": "list_projects", "fn": _t_list_projects,
     "description": "Every Claude Code project on the machine with workflow history (real dirs only).",
     "inputSchema": _obj({})},
    {"name": "list_runs", "fn": _t_list_runs,
     "description": "List OBSERVED Workflow runs in the current project (live first, then newest): "
                    "workflow name, agent count, status (live|incomplete|done), age.",
     "inputSchema": _obj(dict(_SCOPE_PROPS))},
    {"name": "get_run", "fn": _t_get_run,
     "description": "Full OBSERVED graph of one run: phases, agents/nodes, logs, tokens, timing. "
                    "run.taskMatched=false ⇒ the overlay was GC'd and metrics are HEURISTIC/unknown, "
                    "not measured; run.status flags whether an elapsed span is complete or a lower bound.",
     "inputSchema": _obj(dict(_RUN_ID_PROP), ["run_id"])},
    {"name": "list_workflows", "fn": _t_list_workflows,
     "description": "List reusable workflows visible in the current project (builder designs the human "
                    "authored + workflows observed from runs), with honest source and reach.",
     "inputSchema": _obj(dict(_SCOPE_PROPS))},
    {"name": "get_workflow", "fn": _t_get_workflow,
     "description": "Fetch one workflow by name: its runnable Workflow `script` (execute with your own "
                    "Workflow tool), a decoded declared `contract` (inputs + per-agent output schema + "
                    "block/edge skeleton) when hasSidecar, and the runs sharing its name.",
     "inputSchema": _obj({"name": {"type": "string"}}, ["name"])},
    {"name": "get_run_design", "fn": _t_get_run_design,
     "description": "The DECLARED design a specific run EXECUTED, staleness-proof: `script` + `source` "
                    "('snapshot'=exact/'template'=may-differ/null) + decoded `contract`. Use this to "
                    "reproduce a specific observed run; compare against get_run for declared-vs-actual.",
     "inputSchema": _obj(dict(_RUN_ID_PROP), ["run_id"])},
    {"name": "save_workflow", "fn": _t_save_workflow,
     "description": "Draft a Workflow script INTO the human's block builder (appears in list_workflows) "
                    "so they can review/refine it. Returns the path + `editable` honesty flag. Refuses "
                    "to overwrite an existing name unless overwrite=true. Cannot run the workflow.",
     "inputSchema": _obj({"name": {"type": "string"},
                          "script": {"type": "string", "description": "Full Workflow JS (export const meta = {...} + body)"},
                          "overwrite": {"type": "boolean", "description": "Replace an existing same-name workflow in scope (default false)"},
                          **_WRITE_SCOPE}, ["name", "script"])},
    {"name": "promote_run", "fn": _t_promote_run,
     "description": "Promote an existing run into a named, reusable workflow (copies the run's OWN "
                    "script — a builder-launched run yields a faithful editable=true design). Refuses "
                    "if that name already exists in the scope (never clobbers).",
     "inputSchema": _obj({**_RUN_ID_PROP, "name": {"type": "string"}, **_WRITE_SCOPE}, ["run_id", "name"])},
]


# ── JSON-RPC 2.0 plumbing ──

def _ok(mid, result):
    return {"jsonrpc": "2.0", "id": mid, "result": result}


def _err(mid, code, message):
    return {"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": message}}


def _tools_list():
    return {"tools": [{"name": t["name"], "description": t["description"], "inputSchema": t["inputSchema"]}
                      for t in TOOLS]}


def _tools_call(params):
    name = params.get("name")
    args = params.get("arguments") or {}  # absent for no-arg tools
    tool = next((t for t in TOOLS if t["name"] == name), None)
    if not tool:
        return {"content": [{"type": "text", "text": f"unknown tool: {name}"}], "isError": True}
    try:
        # serialize INSIDE the try: a non-JSON-serializable result must surface as an isError tool
        # result, not escape as a JSON-RPC -32603 on the protocol channel.
        result = tool["fn"](args)
        is_err = isinstance(result, dict) and "error" in result
        text = json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:  # tool failures surface as tool RESULTS (isError), so the model can retry
        _log(f"tool {name} failed:", repr(e))
        return {"content": [{"type": "text", "text": f"error in {name}: {e}"}], "isError": True}
    return {"content": [{"type": "text", "text": text}], "isError": is_err}


def handle(msg):
    """Return a JSON-RPC response dict, or None for a notification (no id ⇒ no reply)."""
    mid = msg.get("id")
    if mid is None:  # a notification (notifications/initialized, notifications/cancelled, …) — per
        return None  # JSON-RPC/MCP it MUST NOT get a response; check FIRST, before method dispatch
    method = msg.get("method")
    params = msg.get("params") or {}
    if method == "initialize":
        cv = params.get("protocolVersion")
        return _ok(mid, {"protocolVersion": cv if cv in SUPPORTED_PROTOCOL else DEFAULT_PROTOCOL,
                         "capabilities": {"tools": {"listChanged": False}},
                         "serverInfo": {"name": "workflow-studio", "version": __version__},
                         "instructions": INSTRUCTIONS})
    if method == "tools/list":
        return _ok(mid, _tools_list())
    if method == "tools/call":
        return _ok(mid, _tools_call(params))
    if method == "ping":
        return _ok(mid, {})
    return _err(mid, -32601, f"method not found: {method}")


def serve_stdio(stdin, stdout):
    """Read newline-delimited JSON-RPC from stdin; write one compact response per line to stdout,
    flushing each. Survives bad frames (returns a JSON-RPC error, never crashes); exits on EOF."""
    def _emit(obj):
        stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")  # compact: never multi-line (framing)
        stdout.flush()                                            # or Python block-buffers → client hangs

    while True:
        line = stdin.readline()
        if line == "":  # EOF: client closed stdin → this is the MCP shutdown path
            break
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            _emit(_err(None, -32700, "parse error"))
            continue
        for m in (msg if isinstance(msg, list) else [msg]):
            if not isinstance(m, dict):
                continue
            try:
                resp = handle(m)
            except Exception as e:  # never let one request kill the loop (stdio isn't auto-reconnected)
                _log("dispatch error:", repr(e))
                resp = _err(m.get("id"), -32603, f"internal error: {e}")
            if resp is not None:
                _emit(resp)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="workflow-studio mcp",
                                 description="MCP (stdio) server exposing Workflow Studio to a Claude Code agent.")
    ap.add_argument("--project", default=None, help="project path to scope to (default: $CLAUDE_PROJECT_DIR)")
    ap.add_argument("--all-projects", action="store_true", help="do not scope to a project (whole machine)")
    ap.add_argument("--session", default=None, help="mark a current session (default $CLAUDE_CODE_SESSION_ID)")
    args = ap.parse_args(argv)

    # Resolve project from an explicit flag or CLAUDE_PROJECT_DIR — NOT the uvx cwd (unreliable). When
    # neither is given, launch_project stays None (an honest 'all projects'), never a cwd guess.
    proj_hint = args.project or os.environ.get("CLAUDE_PROJECT_DIR")
    if args.all_projects or not proj_hint:
        _CTX["launch_project"], _CTX["launch_cwd"] = None, (proj_hint or os.getcwd())
    else:
        _CTX["launch_project"] = serve._project_of_cwd(os.path.abspath(proj_hint))
        _CTX["launch_cwd"] = os.path.abspath(proj_hint)
    _CTX["current_session"] = args.session or os.environ.get("CLAUDE_CODE_SESSION_ID") or None

    # Defend the protocol stream: capture the real stdout for the JSON-RPC writer, then point sys.stdout
    # at stderr so any stray print()/warning from imported code can NEVER corrupt the channel.
    real_stdout = sys.stdout
    for stream in (sys.stdin, real_stdout):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")  # keep the channel UTF-8 regardless of locale
    sys.stdout = sys.stderr

    _log(f"ready · project={_CTX['launch_project'] or '(all)'} · "
         f"{len(serve.list_runs(_CTX['launch_project']))} runs in scope · data={serve.DATA_DIR} · v{__version__}")
    try:
        serve_stdio(sys.stdin, real_stdout)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
