"""Workflow Studio — local no-code builder + observability dashboard for Claude Code Workflow runs."""

__version__ = "0.1.0"
