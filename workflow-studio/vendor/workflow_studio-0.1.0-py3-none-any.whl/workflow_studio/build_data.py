#!/usr/bin/env python3
"""
build_data.py — turn a Claude Code Workflow run into a graph JSON for the dashboard.

Reads what the harness already writes to disk:
  - <run-dir>/journal.jsonl         (one started/result line per agent — authoritative outputs)
  - <run-dir>/agent-<id>.jsonl      (per-agent transcript: prompt, thinking, tool calls, text)
  - <run-dir>/agent-<id>.meta.json  (agentType, spawnDepth)
  - <task-output>.output            (workflowProgress: labels, phases, states, tokens — optional)

Works two ways:
  * SNAPSHOT — task-output present → rich, authoritative labels/phases/state/tokens.
  * LIVE     — task-output absent (run still going) → phase/label derived from the prompt
               header + journal order, so nodes still appear as they stream in.

Usage:
  python3 build_data.py --run-dir <dir> [--task-output <file>] [--out data.json]
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime

# ── caps so one node's blob stays readable, not a novel ──
CAP_INPUT = 8000
CAP_THINK = 12000
CAP_OUT = 12000
CAP_TOOL = 1600
MAX_TOOLS = 16

PHASE_ORDER = ["Scope", "Search", "Fetch", "Verify", "Synthesize", "Other"]

# prompt-header → phase (used for LIVE fallback when task-output isn't written yet)
PHASE_MARKERS = [
    ("Decompose this research question", "Scope"),
    ("Web Searcher", "Search"),
    ("Source Extractor", "Fetch"),
    ("Adversarial Claim Verifier", "Verify"),
    ("Synthesis", "Synthesize"),
]


def _truncate(s, n):
    if s is None:
        return ""
    s = s if isinstance(s, str) else json.dumps(s, ensure_ascii=False, indent=2)
    return s if len(s) <= n else s[:n] + f"\n…[+{len(s) - n} znaków]"


def _iso_to_ms(ts):
    """Transcript timestamps are ISO-8601 UTC with a trailing Z (e.g. "…44.732Z"). Parse to
    epoch-MILLISECONDS as UTC — a tz-naive strptime would interpret the wall-time in the
    server's LOCAL zone and silently shift every LIVE timing by the local offset. Using
    fromisoformat with an explicit +00:00 keeps it UTC and tolerates absent/1-6-digit
    fractional seconds (fixed "%f" throws on absent fractions). One bad line → None, never a
    fabricated 0 (the honesty invariant: unknown time is null, not epoch-1970)."""
    if not ts or not isinstance(ts, str):
        return None
    try:
        return int(datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp() * 1000)
    except (ValueError, TypeError):
        return None


def _load_jsonl(path):
    out = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    except FileNotFoundError:
        pass
    return out


def _content_blocks(msg):
    """Anthropic message.content is a string or a list of typed blocks."""
    c = (msg or {}).get("content")
    if isinstance(c, str):
        return [{"type": "text", "text": c}]
    return c if isinstance(c, list) else []


def parse_transcript(path):
    """Pull input / thinking / tool-calls / final text out of an agent transcript."""
    lines = _load_jsonl(path)
    prompt = ""
    thinking_parts = []
    text_parts = []
    tools = []
    pending = {}  # tool_use_id -> tool dict, waiting for its result
    first_ts = last_ts = None  # first/last line wall-clock — the LIVE-mode timing source

    for o in lines:
        t = o.get("type")
        ts = o.get("timestamp")
        if ts:
            if first_ts is None:
                first_ts = ts
            last_ts = ts
        msg = o.get("message") or {}
        if t == "user":
            for b in _content_blocks(msg):
                bt = b.get("type")
                if bt == "text" and not prompt:
                    prompt = b.get("text", "")
                elif bt == "tool_result":
                    tid = b.get("tool_use_id")
                    res = b.get("content")
                    if isinstance(res, list):
                        res = "\n".join(x.get("text", "") for x in res if isinstance(x, dict))
                    if tid in pending:
                        pending[tid]["result"] = _truncate(res, CAP_TOOL)
        elif t == "assistant":
            for b in _content_blocks(msg):
                bt = b.get("type")
                if bt == "thinking":
                    th = (b.get("thinking") or "").strip()
                    if th:
                        thinking_parts.append(th)
                elif bt == "text":
                    tx = (b.get("text") or "").strip()
                    if tx:
                        text_parts.append(tx)
                elif bt == "tool_use":
                    d = {
                        "name": b.get("name", "?"),
                        "input": _truncate(b.get("input"), CAP_TOOL),
                        "result": "",
                    }
                    tools.append(d)
                    pending[b.get("id")] = d

    return {
        "prompt": _truncate(prompt, CAP_INPUT),
        "thinking": _truncate("\n\n───\n\n".join(thinking_parts), CAP_THINK),
        "text": "\n\n".join(text_parts),
        "tools": tools[:MAX_TOOLS],
        "toolCount": len(tools),
        "firstTs": first_ts,
        "lastTs": last_ts,
    }


def derive_phase_and_label(prompt):
    # 1) known deep-research markers → nice phase + label
    for marker, phase in PHASE_MARKERS:
        if marker in prompt:
            label = phase.lower()
            if phase == "Search":
                m = re.search(r"Web Searcher:\s*(.+)", prompt)
                if m:
                    label = "search:" + m.group(1).strip()[:48]
            elif phase == "Fetch":
                m = re.search(r"\*\*URL:\*\*\s*(\S+)", prompt) or re.search(r"URL:\s*(\S+)", prompt)
                host = "?"
                if m:
                    host = re.sub(r"^https?://(www\.)?", "", m.group(1)).split("/")[0]
                label = "fetch:" + host
            elif phase == "Verify":
                m = re.search(r"voter\s*(\d+)", prompt)
                label = "verify:v" + (m.group(1) if m else "?")
            return phase, label
    # 2) generic: first markdown heading "## Base: detail" → phase=Base, label=detail
    m = re.search(r"^#{1,4}\s+(.+)$", prompt, re.M)
    if m:
        head = re.sub(r"[*`]", "", m.group(1)).strip()
        base, _, detail = head.partition(":")
        phase = base.strip()[:24] or "agents"
        label = (detail.strip() or base.strip())[:40]
        return phase, label
    # 3) nothing structured: first non-empty line
    first = next((l.strip() for l in prompt.splitlines() if l.strip()), "agent")
    return "agents", first[:40]


def build(run_dir, task_output, generated_at, status=None):
    journal = _load_jsonl(os.path.join(run_dir, "journal.jsonl"))
    results = {}     # agentId -> result value
    order = []       # agentIds in the order they started
    for o in journal:
        aid = o.get("agentId")
        if not aid:
            continue
        if o.get("type") == "started" and aid not in order:
            order.append(aid)
        elif o.get("type") == "result":
            results[aid] = o.get("result")

    # optional authoritative overlay from the task output
    prog = {}        # agentId -> workflowProgress record
    phase_titles = []
    declared_titles = set()  # titles from workflow_phase records — a 0-agent one is real evidence
    logs = []
    run_summary = ""
    stats = {}
    if task_output and os.path.exists(task_output):
        try:
            with open(task_output, encoding="utf-8") as f:
                to = json.load(f)
            # match_task_output picks any .output that merely MENTIONS one of our agent-ids, so a
            # differently-shaped file (top-level array/scalar, or non-dict records) can reach here —
            # guard every .get so a bad overlay degrades to "no overlay", not an ungraceful 500.
            if not isinstance(to, dict):
                to = {}
            wp = to.get("workflowProgress", [])
            for rec in wp if isinstance(wp, list) else []:
                if not isinstance(rec, dict):
                    continue
                if rec.get("type") == "workflow_phase":
                    t = rec.get("title")
                    if isinstance(t, str) and t.strip():  # drop title-less records (null title
                        phase_titles.append(t)             # would thread None → crash the canvas)
                        declared_titles.add(t)
                elif rec.get("type") == "workflow_agent" and rec.get("agentId"):
                    prog[rec["agentId"]] = rec
            logs = to.get("logs", [])
            res = to.get("result", {})
            run_summary = res.get("summary", "") if isinstance(res, dict) else ""
            stats = res.get("stats", {}) if isinstance(res, dict) else {}
        except (json.JSONDecodeError, OSError):
            pass

    nodes = []
    timing = []  # (clock, startedAt, finishedAt) per agent — for the run-level wall-clock span
    for aid in order:
        tr = parse_transcript(os.path.join(run_dir, f"agent-{aid}.jsonl"))
        meta = {}
        mp = os.path.join(run_dir, f"agent-{aid}.meta.json")
        if os.path.exists(mp):
            try:
                meta = json.load(open(mp, encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass

        p = prog.get(aid)
        if p:
            phase = p.get("phaseTitle") or "Other"
            label = p.get("label") or "agent"
            state = p.get("state") or ("done" if aid in results else "running")
            tokens = p.get("tokens", 0)
            tool_calls = p.get("toolCalls", tr["toolCount"])
            duration = p.get("durationMs", 0)
            model = p.get("model", "")
            last_tool = p.get("lastToolName", "")
            # overlay timing: authoritative epoch-ms from the harness. Default None, NEVER 0 —
            # a queued/not-yet-started agent has a record but no startedAt, and a 0 default
            # would poison min()/max() into a ~56-year "wall-clock" span (the honesty invariant).
            queued_at = p.get("queuedAt")
            started_at = p.get("startedAt")
            finished_at = p.get("lastProgressAt")  # last activity; ≈ end for a done agent
            clock = "overlay"
        else:
            phase, label = derive_phase_and_label(tr["prompt"])
            state = "done" if aid in results else "running"
            tokens = 0
            tool_calls = tr["toolCount"]
            duration = 0
            model = ""
            last_tool = tr["tools"][-1]["name"] if tr["tools"] else ""
            # LIVE fallback: transcript first/last line wall-clock (real, but for a running
            # agent finishedAt is "last activity", not a true end; downstream labels it ≥).
            queued_at = None
            started_at = _iso_to_ms(tr["firstTs"])
            finished_at = _iso_to_ms(tr["lastTs"])
            clock = "transcript"

        out_val = results.get(aid)
        output = _truncate(out_val, CAP_OUT) if out_val is not None else (
            _truncate(tr["text"], CAP_OUT) or "— (brak wyniku / w toku)")

        timing.append((clock, started_at, finished_at))
        nodes.append({
            "id": aid,
            "label": label,
            "phase": phase,
            "state": state,
            "tokens": tokens,
            "toolCalls": tool_calls,
            "durationMs": duration,
            "queuedAt": queued_at,
            "startedAt": started_at,
            "finishedAt": finished_at,
            "clock": clock,  # 'overlay' (authoritative end) | 'transcript' (end = lower bound)
            "model": model,
            "spawnDepth": meta.get("spawnDepth", 0),
            "agentType": meta.get("agentType", ""),
            "lastTool": last_tool,
            "input": tr["prompt"],
            "thinking": tr["thinking"] or "— (brak jawnego myślenia w transkrypcie)",
            "tools": tr["tools"],
            "output": output,
        })

    # phase ordering: task output order if present, else canonical
    if not phase_titles:
        seen = []
        for n in nodes:
            if n["phase"] not in seen:
                seen.append(n["phase"])
        phase_titles = sorted(seen, key=lambda x: PHASE_ORDER.index(x) if x in PHASE_ORDER else 99)
    else:
        # union in any node phase NOT among the declared workflow_phase titles (e.g. an overlay
        # agent whose record lacks phaseTitle → 'Other'). Without this it would get no phaseIndex
        # and vanish from the canvas while still counting in agentCount — an honesty gap.
        for n in nodes:
            if n["phase"] not in phase_titles:
                phase_titles.append(n["phase"])

    phases = []
    idx = 0
    for title in phase_titles:
        members = [n for n in nodes if n["phase"] == title]
        if not members:
            # A DECLARED phase (workflow_phase record) with 0 agents. On a SETTLED run this is real
            # evidence — a branch not taken, or a subwf whose agents ran under a "▸ child" phase —
            # so keep it as an explicit empty phase. On a live/unknown run it's simply not-reached-
            # yet, so skip it (never fabricate a "skipped" claim from a timing artifact).
            if title in declared_titles and status in ("done", "incomplete"):
                phases.append({"index": idx, "title": title, "count": 0, "states": {},
                               "empty": True, "unreached": status == "incomplete"})
                idx += 1
            continue
        st = {}
        for n in members:
            st[n["state"]] = st.get(n["state"], 0) + 1
            n["phaseIndex"] = idx
        phases.append({"index": idx, "title": title, "count": len(members), "states": st})
        idx += 1

    # Run wall-clock span. One clock per run (overlay iff a task-output matched, else
    # transcript), and the span is taken over ONLY the agents on that same clock — never mix
    # overlay epoch-ms with transcript-derived ms, whose zero points can disagree. elapsedMs
    # is the SPAN (max finished − min started), deliberately NOT the sum of per-agent
    # durations (parallel agents overlap; a sum overstates wall-clock). All-None → null, and a
    # negative span (mixed/garbage stamps) collapses to null rather than a fabricated number.
    clock_source = "overlay" if prog else ("transcript" if any(t[0] == "transcript" and t[1] is not None for t in timing) else None)
    span_starts = [s for (c, s, _f) in timing if c == clock_source and s is not None]
    span_finishes = [f for (c, _s, f) in timing if c == clock_source and f is not None]
    run_started = min(span_starts) if span_starts else None
    run_finished = max(span_finishes) if span_finishes else None
    elapsed_ms = (run_finished - run_started) if (run_started is not None and run_finished is not None) else None
    if elapsed_ms is not None and elapsed_ms < 0:
        elapsed_ms = None
    if not span_starts:  # no usable clock → be honest that provenance is unknown
        clock_source = None

    return {
        "run": {
            "runId": os.path.basename(run_dir.rstrip("/")),
            "workflow": "deep-research",
            "generatedAt": generated_at,
            "summary": run_summary,
            "stats": stats,
            "startedAt": run_started,
            "finishedAt": run_finished,
            "elapsedMs": elapsed_ms,
            "clockSource": clock_source,
            "agentCount": len(nodes),
            "phaseCount": len(phases),
        },
        "phases": phases,
        "nodes": nodes,
        "logs": logs,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--task-output", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    jr = os.path.join(args.run_dir, "journal.jsonl")
    generated_at = int(os.path.getmtime(jr)) if os.path.exists(jr) else 0
    data = build(args.run_dir, args.task_output, generated_at)

    payload = json.dumps(data, ensure_ascii=False, indent=None)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(payload)
        print(f"OK → {args.out}  ({len(payload)} B)")
    else:
        sys.stdout.write(payload)

    # human summary to stderr
    print(
        f"agents={data['run']['agentCount']} phases="
        + ", ".join(f"{p['title']}×{p['count']}" for p in data["phases"]),
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
