#!/usr/bin/env python3
"""
serve.py — local server for the workflow dashboard, multi-run edition.

Discovers EVERY workflow run under ~/.claude/projects/*/*/subagents/workflows/wf_*
across all sessions and projects, and lets the dashboard pick which to view (live
runs included). No fixed run — just:

    python3 serve.py [--port 8787]

Endpoints:
    GET /runs                → list of all runs (name, agents, live/done, age)
    GET /data.json?run=<id>  → graph for one run (task-output matched by agentId)
    GET /                    → dashboard.html (+ vendored litegraph)
"""
import argparse
import base64
import functools
import glob
import http.server
import json
import mimetypes
import os
import re
import shutil
import socketserver
import sys
import tempfile
import threading
import time
import urllib.parse
import webbrowser

from . import build_data
from . import __version__

PKG_DIR = os.path.dirname(os.path.abspath(__file__))   # …/workflow_studio
REPO_ROOT = os.path.dirname(PKG_DIR)                    # source checkout root (installed: site-packages)
PROJECTS = os.path.expanduser("~/.claude/projects")
AID_RE = re.compile(r'"agentId":\s*"([a-z0-9]+)"')


def _discover_tasks_root():
    """Where the Workflow runtime writes task-output scratch (…/<name>/<project>/<session>/tasks).
    The old hardcoded /private/tmp/claude-501 only matched the author's Mac. This mirrors Claude
    Code's OWN scratch-dir naming (verified in its bundle: `if windows return "claude"; else
    return claude-<getuid()>`): bare `claude` on Windows, `claude-<uid>` on POSIX, under a temp base.
    An explicit override wins; else probe the usual bases for that dir. Missing → a best guess that
    may not exist — match_task_output already degrades to a heuristic when the scratch is absent."""
    env = os.environ.get("WORKFLOW_STUDIO_TASKS_ROOT")
    if env:
        return env
    name = "claude" if os.name == "nt" else f"claude-{os.getuid() if hasattr(os, 'getuid') else 0}"
    bases, seen = [], set()
    for b in (os.environ.get("TMPDIR"), "/tmp", "/private/tmp", tempfile.gettempdir()):
        if b:
            nb = os.path.normpath(b)
            if nb not in seen:
                seen.add(nb)
                bases.append(nb)
    for b in bases:
        p = os.path.join(b, name)
        if os.path.isdir(p):
            return os.path.realpath(p)        # canonicalize (macOS /tmp → /private/tmp), as CC does
    return os.path.join(bases[0] if bases else tempfile.gettempdir(), name)


def _data_dir():
    """Where user-authored templates + the run→template ledger are WRITTEN. A source checkout keeps
    these beside the code (so existing content is preserved); an installed copy — especially via uvx,
    whose venv is ephemeral/read-only — must use a stable per-user data dir instead."""
    env = os.environ.get("WORKFLOW_STUDIO_DATA")
    if env:
        os.makedirs(env, exist_ok=True)
        return env
    if os.path.isdir(os.path.join(REPO_ROOT, "builder-scripts")) or os.path.isdir(os.path.join(REPO_ROOT, "templates")):
        return REPO_ROOT
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    d = os.path.join(base, "workflow-studio")
    os.makedirs(d, exist_ok=True)
    return d


def _find_dist():
    """The built React app (Vite): bundled inside the package when installed, at repo web/dist in a
    source checkout. An explicit override wins for unusual layouts."""
    for cand in (os.environ.get("WORKFLOW_STUDIO_DIST"),
                 os.path.join(PKG_DIR, "web", "dist"),
                 os.path.join(REPO_ROOT, "web", "dist")):
        if cand and os.path.isdir(cand):
            return os.path.abspath(cand)
    return os.path.join(PKG_DIR, "web", "dist")  # default (may not exist until built)


TASKS_ROOT = _discover_tasks_root()
DATA_DIR = _data_dir()
DIST = _find_dist()
# Legacy static assets (vendor/, dashboard.html) live at the checkout root; installed copies always
# ship the SPA, so the legacy fallback is only ever reached from a source checkout.
STATIC_ROOT = REPO_ROOT if os.path.isdir(os.path.join(REPO_ROOT, "vendor")) else PKG_DIR

_cache = {"t": 0.0, "runs": None, "index": {}}
CACHE_TTL = 2.0


def _run_agent_ids(run_dir):
    return {os.path.basename(f)[6:-6] for f in glob.glob(os.path.join(run_dir, "agent-*.jsonl"))}


def _journal_counts(run_dir):
    started = result = 0
    jp = os.path.join(run_dir, "journal.jsonl")
    try:
        with open(jp, encoding="utf-8", errors="ignore") as f:
            for line in f:
                if '"type":"started"' in line:
                    started += 1
                elif '"type":"result"' in line:
                    result += 1
    except OSError:
        pass
    return started, result


def _workflow_name(run_id):
    # script may live under a different project-slug than the transcripts (cwd-dependent) → glob globally
    hit = glob.glob(os.path.join(PROJECTS, "*", "*", "workflows", "scripts", f"*-{run_id}.js"))
    if hit:
        return re.sub(rf"-{re.escape(run_id)}\.js$", "", os.path.basename(hit[0]))
    return "workflow"


def _pretty_project(slug):
    parts = slug.strip("-").split("-")
    return parts[-1] if parts else slug


# ── templates: a template = a named flow; its runs = executions sharing that name ──
BUILDER_DIR = os.path.join(DATA_DIR, "builder-scripts")
LEDGER = os.path.join(BUILDER_DIR, ".ledger.json")


def _ledger():
    try:
        return json.load(open(LEDGER, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ledger_set(run_id, template):
    d = _ledger()
    d[run_id] = template
    os.makedirs(BUILDER_DIR, exist_ok=True)
    json.dump(d, open(LEDGER, "w", encoding="utf-8"))


_REC_CACHE = {}


def _decode_sidecar_doc(script):
    """The builder doc a script's @wf-builder sidecar decodes to, or None if the sidecar is absent,
    undecodable, or the wrong shape. SINGLE source of the decode+validate the honesty invariant rests
    on — _valid_sidecar, _sidecar_skeleton and sidecar_contract all defer here, so their "is this a
    faithful declared design?" answers can never diverge. A bare regex/substring match is NOT enough
    (a prompt may mention the string; the base64 may be corrupt/version-skewed → lossy parser)."""
    m = re.search(r"/\*\s*@wf-builder\s+([A-Za-z0-9+/=]+)\s*\*/", script or "")
    if not m:
        return None
    try:
        doc = json.loads(base64.b64decode(m.group(1)).decode("utf-8"))
    except (ValueError, TypeError):
        return None
    if isinstance(doc, dict) and isinstance(doc.get("blocks"), list) and isinstance(doc.get("edges"), list):
        return doc
    return None


def _valid_sidecar(script):
    """True iff the script carries a @wf-builder sidecar that DECODES to a valid builder doc (a declared
    design). Gates the overlay + branch stats — a corrupt/mention-only sidecar is NOT a declared design."""
    return _decode_sidecar_doc(script) is not None


SHAPE_CAP = 8  # max nodes drawn in a template-card mini-preview (mirror of CAP in web/src/lib/miniShape.ts)


def _sidecar_skeleton(script):
    """Compact structure skeleton from a builder sidecar, for the template-card mini-preview. DECODE
    ONLY — ships raw facts (true node/edge counts, capped kinds, capped edges with loop/branch flags),
    NEVER a topology label: the client's single TS classifier owns classification, so exact and
    recovered previews can never diverge. Returns None when there is no decodable sidecar, so the
    client falls back to its lazy parse. Mirrors WireShape in web/src/lib/miniShape.ts."""
    doc = _decode_sidecar_doc(script)
    if doc is None:
        return None
    blocks, edges = doc["blocks"], doc["edges"]
    idx, kinds = {}, []                                  # block id -> index INTO kinds[] (append position,
    for b in blocks[:SHAPE_CAP]:                         # NOT the enumerate index — a block without a
        if isinstance(b, dict) and isinstance(b.get("id"), str):  # string id is skipped, so the two must
            idx[b["id"]] = len(kinds)                    # stay in lockstep or edge endpoints misalign)
            kinds.append(b["kind"] if isinstance(b.get("kind"), str) else "agent")
    branch_srcs = {b["id"] for b in blocks
                   if isinstance(b, dict) and b.get("kind") in ("switch", "gate") and isinstance(b.get("id"), str)}
    wire_edges = []
    for e in edges:
        if not isinstance(e, dict):
            continue
        s, t = idx.get(e.get("source")), idx.get(e.get("target"))
        if s is None or t is None:                       # an endpoint fell outside the kept prefix — undrawable
            continue
        flags = 0
        if e.get("rounds") is not None:                  # a back-edge / loop round
            flags |= 1
        if e.get("branch") is not None or e.get("source") in branch_srcs:
            flags |= 2
        wire_edges.append([s, t, flags])
    return {"p": "exact", "n": len(blocks), "k": kinds, "e": wire_edges, "c": len(blocks) > len(kinds)}


def _rename_script(script, new_name):
    """Rewrite a workflow script's identity to `new_name`: the meta.name (so list_templates groups it
    under the chosen name, not the run's original) AND the @wf-builder sidecar's doc name (so the
    block editor and re-save agree). Base64 sidecar payload = UTF-8 JSON, matching serialize.ts."""
    # match SINGLE or DOUBLE quotes — runtime launch scripts emit `name: '...'`, only codegen uses "..."
    script = re.sub(r"(name:\s*)([\"'])[^\"']*\2", lambda m: m.group(1) + m.group(2) + new_name + m.group(2), script, count=1)

    def _reenc(m):
        try:
            doc = json.loads(base64.b64decode(m.group(1)).decode("utf-8"))
            doc["name"] = new_name
            payload = base64.b64encode(json.dumps(doc, ensure_ascii=False).encode("utf-8")).decode("ascii")
            return "/* @wf-builder " + payload + " */"
        except (ValueError, KeyError, TypeError):
            return m.group(0)

    return re.sub(r"/\*\s*@wf-builder\s+([A-Za-z0-9+/=]+)\s*\*/", _reenc, script)


def _run_record(run_id):
    """The Workflow runtime's per-run record (workflows/<run_id>.json): authoritative `workflowName`
    and the FULL launch script — including the @wf-builder sidecar for builder-launched runs. This
    is what lets a run (incl. an in-session tool run, which never writes workflows/scripts/*) surface
    with its real name and its own editable design. Cached by run_id (records are immutable)."""
    if run_id in _REC_CACHE:
        return _REC_CACHE[run_id]
    rec = None
    hit = glob.glob(os.path.join(PROJECTS, "*", "*", "workflows", f"{run_id}.json"))
    if hit:
        try:
            with open(hit[0], encoding="utf-8", errors="ignore") as fh:
                rec = json.load(fh)
        except (OSError, ValueError):
            rec = None
    # Cache ONLY a real record — a None (the runtime finalizes the record at completion, so an
    # in-flight run may be observed before its record lands) must be re-checked on the next call,
    # or the run would be pinned mis-named / non-editable until restart.
    if rec is not None:
        _REC_CACHE[run_id] = rec
    return rec


def _attribution_skill(run_dir):
    for f in glob.glob(os.path.join(run_dir, "agent-*.jsonl"))[:1]:
        try:
            for line in open(f, encoding="utf-8", errors="ignore"):
                m = re.search(r'"attributionSkill":"([^"]+)"', line)
                if m:
                    return m.group(1)
                if '"type":"assistant"' in line:  # first assistant turn is enough
                    break
        except OSError:
            pass
    return None


def template_of(run_dir, run_id):
    """The workflow name for a run: ledger override → the run's OWN record (authoritative) → script
    snapshot name → attributionSkill → generic 'workflow'. The record fixes the case where every
    in-session run collapsed into one 'workflow' entry (no workflows/scripts/* file was written)."""
    led = _ledger()
    if run_id in led:
        return led[run_id]
    rec = _run_record(run_id)
    if rec and rec.get("workflowName"):
        return rec["workflowName"]
    hit = glob.glob(os.path.join(PROJECTS, "*", "*", "workflows", "scripts", f"*-{run_id}.js"))
    if hit:
        return re.sub(rf"-{re.escape(run_id)}\.js$", "", os.path.basename(hit[0]))
    sk = _attribution_skill(run_dir)
    return sk or "workflow"


def _persist_record_script(run_id, run_dir):
    """Write a run's OWN launch script (from its record, incl. sidecar) beside the run dir and return
    the path — so in-session runs (no workflows/scripts/* file) still have a stable, editable source."""
    if not run_dir:
        return None
    rec = _run_record(run_id)
    if not (rec and rec.get("script")):
        return None
    p = os.path.join(run_dir, ".launch-script.js")
    try:
        if not os.path.exists(p):
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(rec["script"])
    except OSError:
        return None
    return p if os.path.exists(p) else None


def _script_of_run(run_id, run_dir=None):
    """Locate the .js a run was launched from: the launch snapshot → the run's own record (persisted)
    → a ledger-linked builder template file."""
    hit = glob.glob(os.path.join(PROJECTS, "*", "*", "workflows", "scripts", f"*-{run_id}.js"))
    if hit:
        return hit[0]
    if run_dir:  # a copy run_design_of already persisted (its snapshot may since have been GC'd)
        persisted = os.path.join(run_dir, ".launch-script.js")
        if os.path.exists(persisted):
            return persisted
    fromrec = _persist_record_script(run_id, run_dir)
    if fromrec:
        return fromrec
    t = _ledger().get(run_id)
    if t:
        for f in glob.glob(os.path.join(TPL_ROOT, "**", "*.js"), recursive=True) + glob.glob(os.path.join(BUILDER_DIR, "*.js")):
            if os.path.basename(f)[:-3] == re.sub(r"[^A-Za-z0-9_-]", "-", t):
                return f
    return None


# ── template scopes: session < project < global ──
TPL_ROOT = os.path.join(DATA_DIR, "templates")


def _project_of_session(sid):
    hit = glob.glob(os.path.join(PROJECTS, "*", sid))
    return os.path.basename(os.path.dirname(hit[0])) if hit and os.path.isdir(hit[0]) else None


def _slug_of_path(path):
    """Claude Code's project slug = the absolute path with every separator turned into '-'. This is
    ENCODE-only (path → slug); we never decode a slug back to a path — '-Users-me-ai-language' is
    genuinely ambiguous — so encoding stays exact."""
    return os.path.abspath(path).replace(os.sep, "-")


def _project_of_cwd(cwd):
    """The project slug a launch directory belongs to, git-root style: the DEEPEST existing ancestor
    whose encoded slug has a project dir on disk. Returns None if cwd is under no known project — the
    caller then shows a chooser rather than fabricating a 'current' scope."""
    p = os.path.abspath(cwd)
    while True:
        if os.path.isdir(os.path.join(PROJECTS, _slug_of_path(p))):
            return _slug_of_path(p)
        parent = os.path.dirname(p)
        if parent == p:
            return None
        p = parent


_CWD_CACHE = {}


def _cwd_of_project(slug):
    """A project's REAL absolute path, read from a transcript's `cwd` field (authoritative) — not
    decoded from the ambiguous slug. `exact` is False only when no transcript carried a cwd and we
    fell back to a best-effort decode, so the UI can flag a guess rather than present it as fact."""
    if slug in _CWD_CACHE:
        return _CWD_CACHE[slug]
    path = None
    # transcripts are `<slug>/<session>.jsonl` at the project root (some layouts also nest one level)
    candidates = glob.glob(os.path.join(PROJECTS, slug, "*.jsonl")) + \
        glob.glob(os.path.join(PROJECTS, slug, "*", "*.jsonl"))
    for jf in sorted(candidates, key=os.path.getmtime, reverse=True)[:3]:
        try:
            with open(jf, encoding="utf-8", errors="ignore") as fh:
                for i, line in enumerate(fh):
                    if i > 50:                 # cwd sits in the session's first records
                        break
                    if '"cwd"' not in line:
                        continue
                    try:
                        obj = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(obj, dict) and isinstance(obj.get("cwd"), str) and obj["cwd"]:
                        path = obj["cwd"]
                        break
        except OSError:
            pass
        if path:
            break
    exact = path is not None
    if not path:                              # ambiguous fallback — marked inexact for the UI
        path = "/" + slug.strip("-").replace("-", "/")
    res = {"path": path, "exact": exact}
    _CWD_CACHE[slug] = res
    return res


def _project_info(slug):
    """Display record for one project: slug + real path + friendly name + session/run counts.
    lastAge tracks RUN recency whenever the project has runs — so a '<runCount> runs · <ago>' label
    is honest — and only falls back to session-dir activity when there are no runs yet (purely for
    ordering). Mixing in session/memory dir mtimes would let unrelated writes read as 'a run just now'."""
    now = time.time()
    pdir = os.path.join(PROJECTS, slug)
    sessions = [d for d in glob.glob(os.path.join(pdir, "*")) if os.path.isdir(d)]
    runs = glob.glob(os.path.join(pdir, "*", "subagents", "workflows", "wf_*"))
    mtimes = [os.path.getmtime(r) for r in runs] or [os.path.getmtime(s) for s in sessions]
    cwd = _cwd_of_project(slug)
    return {
        "slug": slug, "path": cwd["path"], "pathExact": cwd["exact"],
        "name": os.path.basename(cwd["path"].rstrip("/")) or slug,
        "sessionCount": len(sessions), "runCount": len(runs),
        "lastAge": int(now - max(mtimes)) if mtimes else 10 ** 9,
    }


def list_projects():
    """Every project with ≥1 session on disk (the switcher's 'Open Recent'), newest first. Only real
    directories — never fabricated — honoring the honesty invariant."""
    out = []
    for pdir in glob.glob(os.path.join(PROJECTS, "*")):
        slug = os.path.basename(pdir)
        if os.path.isdir(pdir) and any(os.path.isdir(d) for d in glob.glob(os.path.join(pdir, "*"))):
            out.append(_project_info(slug))
    return sorted(out, key=lambda p: p["lastAge"])


def _scope_dir(scope, session=None, project=None):
    if scope == "session" and session:
        return os.path.join(TPL_ROOT, "session", session)
    if scope == "project" and project:
        return os.path.join(TPL_ROOT, "project", project)
    return os.path.join(TPL_ROOT, "global")


def _visible_template_files(project=None, session=None):
    """(path, scope) for every builder template visible in the given scope: global is ALWAYS visible;
    the chosen project's project-scope; and session-scope for that project's sessions (or the one
    `session`). With no project → every stored template (the 'all projects' view)."""
    dirs = [(os.path.join(TPL_ROOT, "global"), "global"), (BUILDER_DIR, "global")]
    if project:
        dirs.append((os.path.join(TPL_ROOT, "project", project), "project"))
        if session:
            dirs.append((os.path.join(TPL_ROOT, "session", session), "session"))
        else:  # every session belonging to this project
            for sdir in glob.glob(os.path.join(PROJECTS, project, "*")):
                if os.path.isdir(sdir):
                    d = os.path.join(TPL_ROOT, "session", os.path.basename(sdir))
                    if os.path.isdir(d):
                        dirs.append((d, "session"))
    else:  # no project scope → show every stored template
        dirs += [(d, "project") for d in glob.glob(os.path.join(TPL_ROOT, "project", "*"))]
        dirs += [(d, "session") for d in glob.glob(os.path.join(TPL_ROOT, "session", "*"))]
    out = []
    for d, sc in dirs:
        for f in glob.glob(os.path.join(d, "*.js")):
            out.append((f, sc))
    return out


def list_sessions(project, current=None):
    """Sessions inside one project with a FRIENDLY label (representative workflow name + run count +
    age), never a bare UUID. `current` (the launch session) is flagged so the UI can pin/mark it.
    Only sessions that actually have workflow runs are listed — an empty session is noise here."""
    out = []
    for sdir in glob.glob(os.path.join(PROJECTS, project, "*")):
        if not os.path.isdir(sdir):
            continue
        runs = glob.glob(os.path.join(sdir, "subagents", "workflows", "wf_*"))
        if not runs:
            continue
        sid = os.path.basename(sdir)
        newest = max(runs, key=os.path.getmtime)
        out.append({
            "sessionId": sid,
            "label": template_of(newest, os.path.basename(newest)),  # representative name, not UUID
            "runCount": len(runs),
            "lastAge": int(time.time() - max(os.path.getmtime(r) for r in runs)),
            "isCurrent": sid == current,
        })
    # current session pinned first, then newest
    return sorted(out, key=lambda s: (not s["isCurrent"], s["lastAge"]))


def discover():
    """Scan disk for all runs. Cached briefly so rapid live-polling is cheap."""
    now = time.time()
    if _cache["runs"] is not None and now - _cache["t"] < CACHE_TTL:
        return _cache["runs"], _cache["index"]

    runs, index = [], {}
    for run_dir in glob.glob(os.path.join(PROJECTS, "*", "*", "subagents", "workflows", "wf_*")):
        if not os.path.isdir(run_dir):
            continue
        run_id = os.path.basename(run_dir)
        sess_dir = os.path.dirname(os.path.dirname(os.path.dirname(run_dir)))
        sess_id = os.path.basename(sess_dir)
        proj_slug = os.path.basename(os.path.dirname(sess_dir))
        started, result = _journal_counts(run_dir)
        n_agents = len(glob.glob(os.path.join(run_dir, "agent-*.jsonl")))
        try:
            mtime = os.path.getmtime(os.path.join(run_dir, "journal.jsonl"))
        except OSError:
            mtime = os.path.getmtime(run_dir)
        age = int(now - mtime)
        if started > result:
            status = "live" if age < 120 else "incomplete"  # recent = still running; stale = died mid-run
        else:
            status = "done"
        runs.append({
            "runId": run_id,
            "workflow": template_of(run_dir, run_id),
            "project": _pretty_project(proj_slug),
            "projectSlug": proj_slug,
            "sessionId": sess_id,
            "session": sess_id[:8],
            "agents": n_agents,
            "done": result,
            "status": status,
            "live": status == "live",
            "ageSec": age,
        })
        index[run_id] = {"run_dir": run_dir, "session_id": sess_id}

    rank = {"live": 0, "incomplete": 1, "done": 2}
    runs.sort(key=lambda r: (rank[r["status"]], r["ageSec"]))  # live first, then newest
    _cache.update(t=now, runs=runs, index=index)
    return runs, index


def match_task_output(run_dir, session_id):
    """Find the .output whose workflowProgress agentIds intersect this run's agents.
    Task outputs live under a cwd-derived project slug that may differ from the
    transcripts' slug, so we search every project for this session's tasks dir.

    The /private/tmp task outputs get GC'd over time — once gone, a run loses its overlay
    (tokens/timing/phase-titles → taskMatched=false, heuristic). So on the FIRST match we
    persist a copy beside the run-dir and fall back to it when the original is gone."""
    persisted = os.path.join(run_dir, ".task-output.json")  # not agent-*.jsonl → ignored by counts
    fids = _run_agent_ids(run_dir)
    if fids:
        cands = []
        for tasks_dir in glob.glob(os.path.join(TASKS_ROOT, "*", session_id, "tasks")):
            cands.extend(glob.glob(os.path.join(tasks_dir, "*.output")))
        for f in sorted(cands, key=os.path.getmtime, reverse=True):
            try:
                txt = open(f, encoding="utf-8", errors="ignore").read()
            except OSError:
                continue
            if set(AID_RE.findall(txt)) & fids:
                try:
                    shutil.copyfile(f, persisted)  # refresh the persisted overlay
                except OSError:
                    pass
                return f
    # original gone (or no agents yet) → use the persisted copy if we saved one earlier
    return persisted if os.path.exists(persisted) else None


def _saved_defs():
    """runId → record path for every workflow Claude Code SAVED (its authoritative `workflows/<runId>.json`
    record — name + full launch script). The 'cc-saved' source is grounded in this file EXISTING, never
    guessed. One glob; records are immutable per runId (cheap enough to read fresh)."""
    out = {}
    for p in glob.glob(os.path.join(PROJECTS, "*", "*", "workflows", "wf_*.json")):
        out[os.path.basename(p)[:-5]] = p
    return out


def list_templates(project=None, session=None, current=None):
    """Every workflow visible in the scope, as a two-axis honest model. SOURCE = what the artifact is
    (run / cc-saved / builder / named), grounded in what exists on disk. REACH = how far it reaches
    (session/project/global) + a `promoted` bit that is TRUE only for a deliberately-placed project/
    global file — a run or cc-saved script is session-local so it can NEVER be promoted, which is what
    makes 'promoted only' honestly free of other-session runs. inCurrent/inSibling let the client split
    'this session' from 'other sessions of this project'. project=None → all projects."""
    runs, _ = discover()
    if project:
        runs = [r for r in runs if r.get("projectSlug") == project]
    if session:
        runs = [r for r in runs if r["sessionId"] == session]
    recs = _saved_defs()
    by = {}
    for r in runs:
        e = by.setdefault(r["workflow"], {"name": r["workflow"], "runCount": 0, "lastAge": 10**9,
                                          "runIds": [], "source": "run", "live": False,
                                          "_sessions": set(), "_bscope": None})
        e["runCount"] += 1
        e["lastAge"] = min(e["lastAge"], r["ageSec"])
        e["runIds"].append(r["runId"])
        e["live"] = e["live"] or r["status"] == "live"
        e["_sessions"].add(r["sessionId"])
        if e["source"] != "builder" and r["runId"] in recs:
            e["source"] = "cc-saved"   # Claude Code saved this definition (a real record exists)
    for f, scope in _visible_template_files(project, session):
        txt = open(f, encoding="utf-8", errors="ignore").read()
        m = re.search(r'name:\s*"([^"]+)"', txt)
        nm = m.group(1) if m else os.path.basename(f)[:-3]
        e = by.setdefault(nm, {"name": nm, "runCount": 0, "lastAge": 10**9, "runIds": [],
                               "source": "builder", "live": False, "_sessions": set(), "_bscope": None})
        e["source"] = "builder"
        e["scriptPath"] = f
        e["_bscope"] = scope
        if scope == "session":
            e["_sessions"].add(os.path.basename(os.path.dirname(f)))
        e["scope"] = scope
        sk = _sidecar_skeleton(txt)   # free: txt is already read; inline EXACT shape for the card preview
        if sk:
            e["shape"] = sk
    for e in by.values():
        sessions = e.pop("_sessions", set())
        bscope = e.pop("_bscope", None)
        if e["source"] == "builder":
            reach = bscope or "global"
            e["promoted"] = reach in ("project", "global")   # a deliberately-placed file
            e["inCurrent"] = reach == "session" and current is not None and current in sessions
            e["inSibling"] = reach == "session" and any(s != current for s in sessions)
        else:                                                # run / cc-saved (session-local, never promoted)
            in_cur = current is not None and current in sessions
            reach = "session" if in_cur else "project"
            e["promoted"] = False
            e["inCurrent"] = in_cur
            e["inSibling"] = any(s != current for s in sessions)
        e["reach"] = reach
        e.setdefault("scope", reach if e["source"] == "builder" else "run")  # back-compat badge field
    return sorted(by.values(), key=lambda e: (e["lastAge"], e["name"]))


def template_detail(name, session):
    # detail is looked up by NAME across ALL scopes (a template's script is the same wherever it's
    # opened from); scoping only governs the LIST, not detail resolution.
    e = next((t for t in list_templates() if t["name"] == name), None)
    if not e:
        return {"error": f"nieznany szablon {name}"}
    sp = e.get("scriptPath")
    # NO [:9000] truncation: the @wf-builder sidecar (declared SchemaField[]) sits at the file
    # TAIL and is the first thing a slice destroys — a schema-rich template would silently lose
    # its declared design. Return the full script so deserializeDoc recovers the sidecar.
    script = open(sp, encoding="utf-8", errors="ignore").read() if sp and os.path.exists(sp) else ""
    if not script and e["runIds"]:                     # run-origin → the run's own script (record/snapshot)
        rid0 = e["runIds"][0]
        _, idx = discover()
        info = idx.get(rid0)
        snap = _script_of_run(rid0, info["run_dir"] if info else None)
        if snap and os.path.exists(snap):
            script = open(snap, encoding="utf-8", errors="ignore").read()
            sp = snap
    runs, _ = discover()
    ids = set(e["runIds"])
    return {"name": name, "source": e["source"], "scriptPath": sp, "script": script,
            "runCount": e["runCount"], "runs": [r for r in runs if r["runId"] in ids]}


def run_design_of(run_id, run_dir=None):
    """The DECLARED design a run actually EXECUTED, staleness-proof. Prefers the run's OWN
    launch-script snapshot (`*-{run_id}.js`) → source 'snapshot'; falls back to a mutable
    ledger-linked template file → 'template' (may differ from what ran); else (None, None).

    Launch snapshots ALSO get GC'd — so on first sight we persist a copy beside the run-dir
    and keep serving it as the run's own 'snapshot' after the original is gone."""
    persisted = os.path.join(run_dir, ".launch-script.js") if run_dir else None
    hit = glob.glob(os.path.join(PROJECTS, "*", "*", "workflows", "scripts", f"*-{run_id}.js"))
    if hit:
        if persisted:
            try:
                shutil.copyfile(hit[0], persisted)
            except OSError:
                pass
        return hit[0], "snapshot"
    if persisted and os.path.exists(persisted):
        return persisted, "snapshot"  # our saved copy of the run's OWN launch script (still exact)
    fromrec = _persist_record_script(run_id, run_dir)  # the run's own record carries the exact script
    if fromrec:
        return fromrec, "snapshot"
    t = _ledger().get(run_id)
    if t:
        norm = re.sub(r"[^A-Za-z0-9_-]", "-", t)
        for f in glob.glob(os.path.join(TPL_ROOT, "**", "*.js"), recursive=True) + glob.glob(os.path.join(BUILDER_DIR, "*.js")):
            if os.path.basename(f)[:-3] == norm:
                return f, "template"
    return None, None


# ── transport-agnostic service layer ──────────────────────────────────────────────────────────
# These functions carry the read/write capabilities WITHOUT the HTTP handler, so both the web server
# (Handler, below) and the MCP server (mcp_server.py) share ONE implementation. The honesty invariant
# lives in the DATA they return — observed run graphs carry taskMatched/status; a design carries its
# `source` ('snapshot' = staleness-proof, 'template' = a mutable fallback that may differ from what
# ran) — never conflate the two. Callers own presentation/error codes.

def resolve_launch_context(project=None, all_projects=False, session=None):
    """The (launch_project slug, launch_cwd, current_session) a process operates under — the SAME
    scoping the web server derives in main(). An MCP server started by Claude Code inherits the
    project dir as cwd, so the default (project=None → os.getcwd()) resolves the right project scope."""
    launch_cwd = os.path.abspath(project) if project else os.getcwd()
    launch_project = None if all_projects else _project_of_cwd(launch_cwd)
    current_session = session or os.environ.get("CLAUDE_CODE_SESSION_ID") or None
    return launch_project, launch_cwd, current_session


def list_runs(project=None, session=None):
    """Observed runs, optionally narrowed to a project slug and/or session id (newest/live first)."""
    runs, _ = discover()
    if project:
        runs = [r for r in runs if r.get("projectSlug") == project]
    if session:
        runs = [r for r in runs if r["sessionId"] == session]
    return runs


def run_data(run_id=None):
    """Full OBSERVED run graph for run_id (or the newest run if None). Returns the build() dict, or a
    {'error': ...} dict when the run is unknown / none exist. build() decorates run.taskMatched
    (False ⇒ heuristic, NOT a measurement) and run.status ('live'|'incomplete'|'done', so an elapsed
    span on a live/incomplete run reads as a lower bound). May raise OSError/ValueError from build()."""
    runs, index = discover()
    if not run_id:
        if not runs:
            return {"error": "brak workflow-runów na dysku"}
        run_id = runs[0]["runId"]
    info = index.get(run_id)
    if not info:
        return {"error": f"nieznany run {run_id}"}
    task_out = match_task_output(info["run_dir"], info["session_id"])
    jr = os.path.join(info["run_dir"], "journal.jsonl")
    gen = int(os.path.getmtime(jr)) if os.path.exists(jr) else 0
    meta = next((x for x in runs if x["runId"] == run_id), {})
    data = build_data.build(info["run_dir"], task_out, gen, status=meta.get("status"))
    data["run"]["runId"] = run_id
    data["run"]["workflow"] = meta.get("workflow", data["run"].get("workflow"))
    data["run"]["live"] = meta.get("live", False)
    data["run"]["status"] = meta.get("status")
    data["run"]["taskMatched"] = bool(task_out)
    return data


def run_design(run_id):
    """The DECLARED design a run EXECUTED — {'script', 'source', 'runId'}. source='snapshot' is the
    run's OWN launch script (exactly what ran, staleness-proof); 'template' is a mutable fallback that
    MAY differ from what ran; None means no design was found. NEVER present this as observed behavior."""
    _, index = discover()
    info = index.get(run_id)
    path, source = run_design_of(run_id, info["run_dir"] if info else None)
    if not path or not os.path.exists(path):
        return {"script": "", "source": None, "runId": run_id}
    try:
        script = open(path, encoding="utf-8", errors="ignore").read()
    except OSError:
        return {"script": "", "source": None, "runId": run_id}
    return {"script": script, "source": source, "runId": run_id}


def branch_stats(template, session=None):
    """Per-run design snapshot + observed empty/taken phases for a template's runs, so declared
    gate/switch markers can be joined to observed branch outcomes. Only 'snapshot'-source designs that
    carry a DECODABLE @wf-builder sidecar are included — a mutable-template fallback or an ad-hoc
    parse would misattribute which branches a run declared."""
    detail = template_detail(template, session)
    runs = [] if detail.get("error") else detail.get("runs", [])
    _, index = discover()
    out = []
    for r in runs[:50]:  # cap; a heavily-run template aggregates its 50 most recent runs
        run_id = r["runId"]
        info = index.get(run_id)
        if not info:
            continue
        run_dir = info["run_dir"]
        path, source = run_design_of(run_id, run_dir)
        if source != "snapshot" or not path or not os.path.exists(path):
            continue  # only the run's own design faithfully says which branches it declared
        try:
            design = open(path, encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        if not _valid_sidecar(design):
            continue  # only a real (decodable) BUILDER design has declared gate/switch markers
        task_out = match_task_output(run_dir, info["session_id"])
        jr = os.path.join(run_dir, "journal.jsonl")
        gen = int(os.path.getmtime(jr)) if os.path.exists(jr) else 0
        data = build_data.build(run_dir, task_out, gen, status=r.get("status"))
        out.append({
            "runId": run_id, "status": r.get("status"), "design": design,
            "phases": [{"title": p["title"], "empty": bool(p.get("empty")), "unreached": bool(p.get("unreached"))}
                       for p in data["phases"]],
        })
    return {"template": template, "runs": out, "capped": len(runs) > 50}


def _resolve_scope_dir(scope, session, launch_project):
    """(dir, effective_scope) for a save. session-scope needs a session, project-scope needs a project
    (the session's, or the launch project); when that context is absent the write DOWNGRADES to global.
    Returns the scope ACTUALLY achieved so callers report where the file really landed (its real, often
    broader, visibility) — never the requested-but-unmet scope, which would misstate visibility."""
    project = _project_of_session(session) if session else launch_project
    scope = scope or "global"
    if scope == "session" and session:
        effective = "session"
    elif scope == "project" and project:
        effective = "project"
    else:
        effective = "global"
    d = _scope_dir(effective, session, project)
    os.makedirs(d, exist_ok=True)
    return d, effective


def save_template(name, script, scope="global", session=None, launch_project=None, overwrite=True):
    """Persist a Workflow script into its scope. Returns (result, http_code). `editable` reflects
    whether the script's @wf-builder sidecar DECODES (True ⇒ faithfully editable in the block editor;
    False ⇒ opens via LOSSY recovery — an agent-authored script has no sidecar). With overwrite=False,
    refuses (409) when a file of that name already exists in the scope, so a caller writing into a
    shared namespace never silently clobbers the human's own template. Empty script → 400."""
    if not (script or "").strip():
        return {"error": "pusty skrypt — nie zapisuję"}, 400
    name = re.sub(r"[^A-Za-z0-9_-]", "-", (name or "builder"))[:60] or "builder"
    scope_dir, effective_scope = _resolve_scope_dir(scope, session, launch_project)
    path = os.path.join(scope_dir, name + ".js")
    if not overwrite and os.path.exists(path):
        return {"error": f"'{name}' już istnieje w tym zakresie — użyj overwrite lub innej nazwy"}, 409
    with open(path, "w", encoding="utf-8") as f:
        f.write(script)
    return {"path": path, "name": name, "scope": effective_scope, "editable": _valid_sidecar(script)}, 200


def sidecar_contract(script):
    """Decode a script's @wf-builder sidecar into the DECLARED contract an agent needs to read/run a
    design: name, declared inputs (param/input/start blocks), every block's declared output schema, and
    the edge skeleton. Returns None when there is NO decodable sidecar — never fabricates a contract
    from a lossy parse (callers pair this with hasSidecar). Shares _decode_sidecar_doc with
    _valid_sidecar/_sidecar_skeleton so all three agree on what counts as a faithful design."""
    doc = _decode_sidecar_doc(script)
    if doc is None:
        return None
    blocks = [b for b in doc["blocks"] if isinstance(b, dict)]

    def _summ(b):
        sch = b.get("schema")
        return {"id": b.get("id"), "kind": b.get("kind"), "label": b.get("label"),
                "schema": sch if isinstance(sch, (list, dict)) else None}

    return {
        "name": doc.get("name"),
        "cycleRounds": doc.get("cycleRounds"),
        "inputs": [_summ(b) for b in blocks if b.get("kind") in ("param", "input", "start")],
        "blocks": [_summ(b) for b in blocks],
        "edges": [{"source": e.get("source"), "target": e.get("target"),
                   "rounds": e.get("rounds"), "branch": e.get("branch")}
                  for e in doc["edges"] if isinstance(e, dict)],
    }


def make_template(run_id, name, scope="global", session=None, launch_project=None):
    """Promote a run into a named, reusable builder template (copy its OWN script, re-identified to
    `name`). Returns (result_dict, http_code): 400 if the run's script is missing, 409 if a distinct
    template of that name already exists in the scope (never silently clobbered), else 200 with
    `editable` (True only if the copied script's @wf-builder sidecar actually decodes)."""
    _, idx = discover()
    info = idx.get(run_id)
    src = _script_of_run(run_id, info["run_dir"] if info else None)
    if not src or not os.path.exists(src):
        return {"error": "nie znaleziono skryptu tego runu"}, 400
    name = re.sub(r"[^A-Za-z0-9_-]", "-", name or "")[:60] or "szablon"
    dst_dir, effective_scope = _resolve_scope_dir(scope, session, launch_project)
    dst = os.path.join(dst_dir, name + ".js")
    if os.path.exists(dst):
        return {"error": f"szablon '{name}' już istnieje w tym zakresie — wybierz inną nazwę"}, 409
    script = open(src, encoding="utf-8", errors="ignore").read()
    editable = _valid_sidecar(script)
    with open(dst, "w", encoding="utf-8") as fh:
        fh.write(_rename_script(script, name))
    return {"path": dst, "name": name, "scope": effective_scope, "editable": editable}, 200


def link_run(run_id, template):
    """Record runId → template in the ledger so a builder-launched run attributes to its template.
    `ok` reflects whether a link was actually written (both ids present), never a blanket True."""
    if run_id and template:
        _ledger_set(run_id, template)
        return {"ok": True}
    return {"ok": False}


class Handler(http.server.SimpleHTTPRequestHandler):
    launch_project = None   # default project scope (slug) from cwd; None = cwd is not a known project
    launch_cwd = None       # absolute launch directory (display / empty state)
    current_session = None  # session marked "• current" (--session or $CLAUDE_CODE_SESSION_ID)

    def _params(self):
        return urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")

    def _scope(self, qs):
        """(projectSlug, sessionId) from query params. Project defaults to the launch project;
        `projekt=wszystkie` (or legacy all=1 / zakres=wszystkie) means all projects (None)."""
        proj_q = (qs.get("projekt") or qs.get("project") or [""])[0]
        all_q = (qs.get("all") or ["0"])[0] == "1" or (qs.get("zakres") or [""])[0] == "wszystkie"
        if proj_q == "wszystkie" or all_q:
            project = None
        elif proj_q:
            project = proj_q
        else:
            project = self.launch_project
        session = (qs.get("sesja") or qs.get("session") or [None])[0]
        return project, session

    def do_GET(self):
        path = self.path.split("?")[0]
        # ── data API (always wins over the static app) ──
        if path == "/runs":
            return self._runs()
        if path in ("/data.json", "/data.json/"):
            return self._data()
        if path == "/context":
            return self._context()
        if path == "/projects":
            return self._json({"projects": list_projects(), "launchProject": self.launch_project,
                               "currentSession": self.current_session})
        if path == "/resolve-project":
            return self._resolve_project()
        if path == "/templates":
            qs = self._params()
            project, session = self._scope(qs)
            return self._json({"project": project, "showingAll": project is None,
                               "currentSession": self.current_session,
                               "templates": list_templates(project, session, self.current_session)})
        if path == "/template":
            qs = self._params()
            _, session = self._scope(qs)
            return self._json(template_detail((qs.get("name") or [""])[0], session))
        if path == "/run-design":
            return self._run_design()
        if path == "/branch-stats":
            return self._branch_stats()
        if path == "/sessions":
            qs = self._params()
            project, _ = self._scope(qs)
            project = project or self.launch_project
            return self._json({"project": project, "currentSession": self.current_session,
                               "sessions": list_sessions(project, self.current_session) if project else []})
        # ── built React SPA (Vite) if present, else legacy dashboard.html ──
        if os.path.isdir(DIST):
            return self._serve_spa(path)
        if path in ("/", "/index.html"):
            self.path = "/dashboard.html"
        return super().do_GET()

    def _serve_spa(self, path):
        """Serve a built asset by path, else fall back to index.html for client routing."""
        rel = urllib.parse.unquote(path).lstrip("/")
        candidate = os.path.normpath(os.path.join(DIST, rel))
        if rel and candidate.startswith(DIST + os.sep) and os.path.isfile(candidate):
            return self._send_file(candidate, cache=rel.startswith("assets/"))
        return self._send_file(os.path.join(DIST, "index.html"), cache=False)

    def _send_file(self, path, cache=False):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            return self.send_error(404)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control",
                         "public, max-age=31536000, immutable" if cache else "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        route = self.path.split("?")[0]
        if route == "/save":
            return self._save()
        if route == "/make-template":
            return self._make_template()
        if route == "/link":
            return self._link()
        return self.send_error(404)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def _make_template(self):
        """Promote a run into a reusable, named builder template (delegates to make_template)."""
        try:
            b = self._body()
            session = b.get("session") or self.current_session
            res, code = make_template(b.get("run", ""), b.get("name") or "", b.get("scope", "global"),
                                      session, self.launch_project)
            return self._json(res, code)
        except (ValueError, OSError) as e:
            return self._json({"error": str(e)}, 400)

    def _link(self):
        """Record runId → template so builder-launched runs attribute correctly."""
        try:
            b = self._body()
            return self._json(link_run(b.get("run"), b.get("template")))
        except (ValueError, OSError) as e:
            return self._json({"error": str(e)}, 400)

    def _save(self):
        """Persist a builder-generated Workflow script into its scope; return its path."""
        try:
            body = self._body()
            session = body.get("session") or self.current_session
            res, code = save_template(body.get("name"), body.get("script", ""),
                                      body.get("scope", "global"), session, self.launch_project)
            return self._json(res, code)
        except (ValueError, OSError) as e:
            return self._json({"error": str(e)}, 400)

    def _runs(self):
        qs = self._params()
        project, session = self._scope(qs)
        runs, _ = discover()
        if project:
            runs = [r for r in runs if r.get("projectSlug") == project]
        if session:
            runs = [r for r in runs if r["sessionId"] == session]
        return self._json({
            "project": project,                 # active project slug (None = all projects)
            "session": session,                 # active session narrow (None = all sessions)
            "currentSession": self.current_session,
            "launchProject": self.launch_project,
            "showingAll": project is None,
            "runs": runs,
        })

    def _context(self):
        """Startup context for the SPA: the launch project (from cwd), the cwd itself, the current
        session to mark, and how many projects exist (drives the empty/chooser states)."""
        return self._json({
            "launchProject": _project_info(self.launch_project) if self.launch_project else None,
            "launchCwd": self.launch_cwd,
            "currentSession": self.current_session,
            "projectCount": len(list_projects()),
            "version": __version__,
        })

    def _resolve_project(self):
        """Validate a pasted absolute path → real project (the switcher's escape hatch). Honest: only
        resolves a directory that actually has Claude Code history under ~/.claude/projects."""
        qs = self._params()
        raw = (qs.get("path") or [""])[0]
        slug = _project_of_cwd(raw) if raw else None
        if not slug:
            return self._json({"error": "Ten katalog nie ma historii Claude Code.", "path": raw}, 404)
        return self._json(_project_info(slug))

    def _json(self, obj, code=200):
        payload = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _data(self):
        try:
            qs = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
            data = run_data((qs.get("run") or [None])[0])
            return self._json(data, 404 if "error" in data else 200)
        except (OSError, ValueError) as e:
            return self._json({"error": f"build failed: {e}"}, 500)

    def _run_design(self):
        """The declared design THIS run executed (delegates to run_design); `source` distinguishes the
        run's own snapshot (staleness-proof) from a mutable template fallback."""
        qs = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
        return self._json(run_design((qs.get("run") or [""])[0]))

    def _branch_stats(self):
        """Per-run design snapshot + observed phases for a template's runs (delegates to branch_stats)."""
        qs = self._params()
        _, sess = self._scope(qs)
        return self._json(branch_stats((qs.get("template") or [""])[0], sess))

    def log_message(self, fmt, *args):
        msg = args[0] if args else ""
        if "/data.json" not in msg and "/runs" not in msg:
            super().log_message(fmt, *args)


def _bind(host, port, explicit):
    """Bind the server. An explicit --port is honored strictly; otherwise scan a few ports so a busy
    default (8787) doesn't stop the app from starting. Returns (server, actual_port)."""
    socketserver.TCPServer.allow_reuse_address = True
    handler = functools.partial(Handler, directory=STATIC_ROOT)
    last = None
    for p in ([port] if explicit else [port + i for i in range(20)]):
        try:
            return socketserver.TCPServer((host, p), handler), p
        except OSError as e:
            last = e
    raise SystemExit(f"nie mogę zająć portu {port} na {host}: {last}")


def main():
    # `workflow-studio mcp [...]` runs the MCP (stdio) server for a Claude Code agent instead of the
    # web dashboard. Dispatch BEFORE argparse (argparse would reject 'mcp' as an unknown positional),
    # and strip the subcommand token so mcp_server sees only its own flags. The bare `workflow-studio`
    # keeps launching the web server, so this is purely additive.
    if len(sys.argv) > 1 and sys.argv[1] == "mcp":
        from . import mcp_server
        return mcp_server.main(sys.argv[2:])

    ap = argparse.ArgumentParser(prog="workflow-studio",
                                 description="Lokalny builder + podgląd przebiegów Workflow (Claude Code).")
    ap.add_argument("--port", type=int, default=None,
                    help="port (domyślnie 8787 lub $PORT; zajęty → szuka następnego wolnego)")
    ap.add_argument("--host", default="127.0.0.1", help="adres nasłuchu (domyślnie tylko localhost)")
    ap.add_argument("--project", default=None,
                    help="(zaawansowane) ścieżka projektu zamiast bieżącego katalogu")
    ap.add_argument("--all-projects", action="store_true",
                    help="pokaż przebiegi ze wszystkich projektów na maszynie")
    ap.add_argument("--session", default=None,
                    help="(zaawansowane) zawęź do jednej sesji; domyślnie $CLAUDE_CODE_SESSION_ID")
    ap.add_argument("--no-open", action="store_true",
                    help="nie otwieraj przeglądarki (lub ustaw WORKFLOW_STUDIO_NO_OPEN)")
    args = ap.parse_args()

    explicit = args.port is not None
    port = args.port if explicit else int(os.environ.get("PORT") or "8787")

    # Default scope = the project of the launch directory (like `code .`), git-root style. --project
    # overrides the dir; --all-projects opts into the whole-machine view. --session only MARKS the
    # current session within the project (no longer the top scope), defaulting to the CC env var.
    Handler.launch_project, Handler.launch_cwd, Handler.current_session = \
        resolve_launch_context(args.project, args.all_projects, args.session)

    httpd, port = _bind(args.host, port, explicit)
    with httpd:
        all_runs, _ = discover()
        lp = Handler.launch_project
        if lp:
            n = sum(1 for r in all_runs if r.get("projectSlug") == lp)
            scope = f"projekt {os.path.basename(_cwd_of_project(lp)['path'].rstrip('/')) or lp} ({n} runów)"
        elif args.all_projects:
            scope = f"wszystkie projekty ({len(all_runs)} runów)"
        else:
            scope = f"katalog bez historii CC — wybierz projekt w UI ({len(all_runs)} runów na maszynie)"
        ui = "React SPA (web/dist)" if os.path.isdir(DIST) else "dashboard.html (legacy)"
        open_host = "127.0.0.1" if args.host in ("0.0.0.0", "::") else args.host
        url = f"http://{open_host}:{port}/"
        print(f"▶ Workflow Studio: {url}   [{ui}]")
        print(f"  zakres: {scope} · dane: {DATA_DIR} · auto-odświeżanie co {CACHE_TTL}s")
        print("  Ctrl+C aby zatrzymać")
        if not (args.no_open or os.environ.get("WORKFLOW_STUDIO_NO_OPEN")):
            threading.Timer(0.4, lambda: webbrowser.open(url)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n zatrzymano.")


if __name__ == "__main__":
    main()
